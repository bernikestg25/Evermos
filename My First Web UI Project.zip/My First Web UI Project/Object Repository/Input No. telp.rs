<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Input No. telp</name>
   <tag></tag>
   <elementGuidId>9497398d-c559-43ff-81f5-575e50431d42</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;__layout&quot;]/div[2]/div[1]/form/label[1]/span[2]/input</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>-webkit-font-smoothing: antialiased;
box-sizing: inherit;
margin: 0;
overflow: visible;
position: relative;
display: block;
width: 100%;
height: 30px;
border: none;
outline: none;
font-family: inherit;
background: transparent;
line-height: inherit;
font-size: inherit;
padding: 6px 0;
transition: inherit;
text-transform: inherit;
z-index: 2;
color: inherit;</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
